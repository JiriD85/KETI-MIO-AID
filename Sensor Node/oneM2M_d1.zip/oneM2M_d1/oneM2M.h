/*
 *	oneM2M.h
 *
 *	copyright (c) Andreas Kraft 2018
 *	Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *	Implementation of a small subset oneM2M's resources and Mca interface.
 */

# ifndef __ONEM2M_H__
# define __ONEM2M_H__

# include "HttpServer.h"
# include "LinkedList.h"
# include <WiFiClientSecure.h>
# include <ArduinoHttpClient.h>

class OneM2M {
public:

	// Enumeration for oneM2M resource types
	enum ResourceType {
		UNKNOWN = -1,
		ACCESSCONTROLPOLICY = 1,
		AE = 2, 
		CONTAINER = 3, 
		CONTENTINSTANCE = 4, 
		CSE = 5,
		DELIVERY = 6,
		EVENTCONFIG = 7,
		EXECINSTANCE = 8,
		GROUP = 9,
		LOCATIONPOLICY = 10,
		M2MSERVICESUBSCRIPTIONPROFILE = 11,
		MGMTCMD = 12,
		MGMTOBJ = 13,
		NODE = 14,
		pollingChannel = 15,
		REMOTECSE = 16,
		REQUEST = 17,
		SCHEDULE = 18,
		SERVICESUBSCRIBEDAPPRULE = 19,
		SERVICESUBSCRIBEDNODE = 20,
		STATSCOLLECT = 21,
		STATSCONFIG = 22,
		SUBSCRIPTION = 23,
		SEMANTICDESCRIPTOR = 24,
		NOTIFICATIONTARGETMGMTPOLICYREF = 25,
		NOTIFICATIONTARGETPOLICY = 26,
		POLICYDELETIONRULES = 27,
		FLEXCONTAINER = 28,
		TIMESERIES = 29,
		TIMESERIESINSTANCE = 30,
		ROLE = 31,
		TOKEN = 32,
		TRAFFICPATTERN = 33,
		DYNAMICAUTHORIZATIONCONSULTATION = 34,
		AUTHORIZATIONDECISION = 35,
		AUTHORIZATIONPOLICY = 36,
		AUTHORIZATIONINFORMATION = 37,
		ONTOLOGYREPOSITORY = 38,
		ONTOLOGY = 39,
		SEMANTICMASHUPJOBPROFILE = 40,
		SEMANTICMASHUPINSTANCE = 41,
		SEMANTICMASHUPRESULT = 42,
		AECONTACTLIST = 43,
		AECONTACTLISTPERCSE = 44
	};

  // Enumeration for oneM2M ManagementObj types
  enum MgmtObjType {
    FWR       = 1001,
    SWR       = 1002,
    MEM       = 1003,
    ANI       = 1004,
    ANDI      = 1005,
    BAT       = 1006,
    DVI       = 1007,
    DVC       = 1008,
    RBO       = 1009,
    EVL       = 1010,
    NYCFC     = 1023
  };


	// Structure to hold the results when retrieving a content instance.
	struct Content {
		String 	resourceIdentifier;		// Resource identifier of the resource
		String 	content;				// Actual content
		String 	contentFormat;			// Content format description
		String 	creationTime;			// Creation time of the resource
    int     stateTag;          // stateTag attribute
		bool    state;					// Indicate the resource's retrieval state 
	};

	// typedef for notification callback functions
	typedef void (*NotificationCallback)(String resourceIdentifier, OneM2M::ResourceType type, String resource);


private:

	struct PathElements {
		String path;
		String rn;
	};

	struct NotificationCBStruct {
		String 					subscriptionResourceID;
		NotificationCallback 	callback;
		// calback
	};

	String 										    _host;
	int										  	    _port;
  boolean                       _secureConnection;
  boolean                       _oauthEnabled;
	String 										    _basePath;
	String 										    _originator;
  String                        _cseRN;

  static String                 _version;       // oneM2M release version
	static int 		 							  _jsonSize;			// Size for JSON buffers
  static int                    _requestTimeout;  // in ms
  static String                 _contentType;
	static HttpServer						 *_notificationServer;
	static String		 						  _notificationURL;
	static LinkedList<NotificationCBStruct *>	 _notificationCallbacks;


	OneM2M();	// prevent usage of simple ctor

	String 										         _getPath(String resourceName);
  void                               _sendHttpHeaders(HttpClient client, String contentLength = "", String originator = "", String contentType = "application/json", String authToken = "");
  String                             _getOAuthToken();



	static NotificationCBStruct 		  *_getCallback(String resourceIdentifier);
	static ResourceType 						   _getCallbackType(String resourceIdentifier);
	static HttpServer::RequestResult	 _notificationRequestHandler(String path, 
																			 HttpServer::Method method, 
																			 long length,
																			 String type, 
																			 char *content);
	static String 								    _getRequestContent(WiFiClient &client, int expectedReturnCode);
	static PathElements 					    _splitPath(String path);
	static String 						    		_escapeJSON(String value); 
  static String                     _getRandomID();
  


public:

	//	Most of the CSE-access methods return a String object. If the call was
	//	successful, then this string contains the full answer to the request
	//	from the CSE. Usually and if not stated otherwise in the descriptions
	//	below, this is a JSON encoded oneM2M resource. If the call was not
	//	successful, then this String is empty (length == 0).

	//	The class's constructor.  
	//	*host* specifies the host name to the CSE, while 
	//	*port* specifies the CSE's port. *basePath* is an optional path for the CSE.
  //  *secureConnection* use https for connecting to the CSE.
  //  *oauthEnabled* use OAuth to authenticate the connection to the CSE.
  //  *path* an optional path prefix.
	//	*originator* is originator to access the CSE.
  //  *cseRN* is the CSE's resourceName.
	OneM2M(String host, int port, boolean secureConnection, boolean oauthEnabled, String basePath, String originator, String cseRN);


	//	Retrieve the CSEBase resource.
	String 			getCSE(void);


	//
	//	AE
	//

	//	Retrieve an AE resource. The AE is created in case it does not exist yet.
	//	*path* is the resource path of the aE resource. The last path
	//	element must be the resource name of the Subscription.
	//	*aeID* is the application ID of that AE.
	String 			getAE(String path, String aeID);

	//	Retrieve an AE resource.
	//	*path* is the resource path of the AE resource. The last path element
	//	must be	the resource name of the AE.
	//	*appID* is the application ID of that AE.
	String 			retrieveAE(String path, String originator);

	//	Register an AE. 
	//	*path* is the resource path of the AE resource. The last path element
	//	must be the resource name of the AE.
	//	*aeID* is the application ID of that AE.
	String 			registerAE(String path, String aeID);

  // TODO doc
  String      updateAE(String path, String originator, String attributes);



  //
  //  Node
  //  TODO doc
  //

  //  Retrieve a Node resource. The Node is created in case it does
  //  not exist yet.  
  //  *path* is the resource path of the Node resource. The last path
  //  element must be the resource name of the Node.
  String      getNode(String path, String originator, String nodeID, String aeID);

  //  Retrieve a Node resource.
  //  *path* is the resource path of the Node. The last path element 
  //  must be the resource name of the Node.
  String      retrieveNode(String path, String originator);

  //  Create a Node.
  //  *path* is the resource path of the Container. The last path element
  //  must be the resource name of the Container.
  String      createNode(String path, String originator, String nodeID, String aeID);


  //
  //  MgmtObjs
  //  TODO doc
  //

  //  Retrieve a Node resource. The Node is created in case it does
  //  not exist yet.  
  //  *path* is the resource path of the Node resource. The last path
  //  element must be the resource name of the Node.
  String   getMgmtObj(String path, String originator, String tpe, OneM2M::MgmtObjType mgd, String dc, String attributes);

  //  Retrieve a Node resource.
  //  *path* is the resource path of the Node. The last path element 
  //  must be the resource name of the Node.
  String  retrieveMgmtObj(String path, String originator);

  //  Create a Node.
  //  *path* is the resource path of the Container. The last path element
  //  must be the resource name of the Container.
  String  createMgmtObj(String path, String Originator, String tpe, OneM2M::MgmtObjType mgd, String dc, String attributes);

  String  updateMgmtObj(String path, String originator, String tpe, String attributes);

	//
	//	Container
	//

	//	Retrieve a Container resource. The Container is created in case it does
	//	not exist yet.  
	//	*path* is the resource path of the Container resource. The last path
	//	element must be the resource name of the Container.
	String 			getContainer(String path, String originator, int mni = 0);

	//	Retrieve a Container resource.
	//	*path* is the resource path of the Container. The last path element 
	//	must be the resource name of the Container.
	String 			retrieveContainer(String path, String originator);

	//	Create a Container.
	//	*path* is the resource path of the Container. The last path element
	//	must be the resource name of the Container.
	String 			createContainer(String path, String originator, int mni = 0);


	//
	//	ContentInstance
	//

	//	Add a ContentInstance resource to a Container, with a default content
	//	type of *text/plain:0*.  
	//	*path* is the resource path of the Container, NOT the ContentInstance.
	//	*content* is the actual content of the ContentInstance. 
	String 			createContentInstance(String path, String originator, String content);

	//	Add a ContentInstance resource to a Container with the possibility to
	//	specifying a content type.
	//	*path* is the resource path of the Container, NOT the ContentInstance.
	//	*content* is the actual content of the ContentInstance. *contentType* 
	//	is the content's content type.
	String 			createContentInstance(String path, String originator, String content, String contentType);

	//	Retrieve the latest content instance from the CSE.  
	//	*path* is the resource path of the Container, NOT the ContentInstance.  
	//	This method returns a *Content* structure that contains the content, 
	//	content type, and creation date of the retrieved content instance.
	Content 		retrieveLatestContentInstance(String path, String originator);

	//	Extract the *Content* information from a JSON-encoded resource String.
	//	*resource* is the JSON-encoded resource.
	//	This method returns a *Content* structure that contains the content, 
	//	content type, and creation date of the retrieved content instance.
	Content 		contentFromContentInstance(String resource);


	//
	//	Subscription
	//

	//	Retrieve a Subscription resource. The Subscription is created in case
	//	it does not exist yet. 
	//	*path* is the resource path of the Subscription resource. The last path
	//	element must be the resource name of the Subscription.
	String 			getSubscription(String path, String originator, String notificationURI = "");

	//	Retrieve a Subscription resource.
	//	*path* is the resource path of the Subscription. The last path element 
	//	must be the resource name of the Subscription.
	String 			retrieveSubscription(String path, String originator);

	//	Add a Subscription resource to another resource.  
	//	*path* is the resource path of the Subscription resource. The last path
	//	element must be the resource name of the Subscription.
	String 			createSubscription(String path, String originator, String notificationURI = "");

	//	Retrieve a Subscription resource. The Subscription is created in case
	//	it does not exist yet. In addition a notification callback function
	//	is registered for this subscription.
	//	*path* is the resource path of the Subscription resource. The last path
	//	element must be the resource name of the Subscription.
	//	*callback* is the callback function for notifications for this  
	//	subscription.
	String 			getSubscriptionNotify(String path, String originator, NotificationCallback callback, String notificationURI = "");


	//	Create a resource on the CSE.
	//	*path* is the resource path of the resource. The last path element 
	//	must be the new resource name of the resource.
	//	*type* is the resource type of the new resource.
	//	*content* must contain a valid resource in JSON encoding.
	String 			CREATE(String path, String originator, int type, String content);

	//	Retrieve a resource from the CSE.
	//	*path* is the resource path of the resource.
	String 			RETRIEVE(String path, String originator);

	//	Update an existing resource on the CSE.
	//	*path* is the resource path of the resource.
	//	*content* must contain a valid resource update in JSON encoding. 
	String 			UPDATE(String path, String originator, String content);

	//	Delete a resource from the CSE.
	//	*path* is the resource path of the resource.
	String			DELETE(String path, String originator);


	//////////////////////////////////////////////////////////////////////////
	//
	// 	Static Functions
	//

	//
	// 	Notification Functions
	//

	//	Setup and initialize the notification sub-system. This method starts
	//	an HTTP server that listens on port 1440 for notification events from
	//	connected CSEs. There is only notification one sub-system for all 
	//	instances of the OneM2M class.
	//	This or another setup method must be called before Subscription 
	//	resources can be created and notifications can be received.
	static void 	setupNotifications(String aeOriginator);

	//	Setup and initialize the notification sub-system. This method works the
	//	same as the method without parameters, but with this method one can
	//	specify own parameters for the HTTP server setup.
	//	*host* is the external host address of the HTTP server to bind to.
	//	*port* is the port to bind to.
	//	*path* is the path on the HTTP server for notifications.
	static void 	setupNotifications(String host, int port, String path);

	//	Shutdown the notification sub-system. This also shuts down the HTTP
	//	server. After the shutdown no notifications will be received and no
	//	new Subscription resources can be created.
	static void 	shutdownNotifications(void);

	//	Add a callback function for a specific subscription's resource ID that 
	//	is called when a notification for that subscription is received. The 
	//	method canbe called multiple times to update the callback function for 
	//	the same resource ID.
	//	*subscriptionResourceID* is the resource ID of the subscription.
	//	*callback* is a pointer to a function that will receive the 
	//	notification information. See also the description for 
	//	*NotificationCallback*.
	//	The method returns true when the addition / update was successful.
	static bool 	addNotificationCallback(String subscriptionResourceID, NotificationCallback callback);

	//	Remove the callback function for specific subscription's resource ID.
	//	*subscriptionResourceID* is the resource ID of the subscription.
	//	The method returns true when the removal was successful.
	static bool 	removeNotificationCallback(String subscriptionResourceID);

	//	This method handles receiving and processing of incoming notifications.
	//	This method must be called very regurlarly (e.g. every few hundred
	//	milliseconds) to check for incoming notification requests from the CSE.  
	static void		checkNotifications(void);

  //  Return the notification URL 
  static String getNotificationURL(void);



	//
	// 	Miscellaneous Functions
	//

	//	Set the size of the internal JSON buffers. Since memory is very limited
	//	on Arduino devices the buffers for parsing JSON structures are limited
	//	to *1024* bytes by default. If, for example, large ContentInstance 
	//	resources are retrieved then the maximum buffer size must be increased.
	//	*size* is the new maximum size for internal JSON buffers.
	static void 	setJsonMaxSize(int size);

	//	Return the current set size of internal JSON buffers.
	static int 		jsonMaxSize(void);

	//	Get the resource ID from a JSON-encoded resource.
	//	*resource* is a JSON-encoded resource.
  //  *tpe* is the type name of the resource, e.g. "m2m:sub"
	//	This method returns the resource ID as a string.
	static String 	getResourceIdentifier(String resource, String tpe);

};

# endif
