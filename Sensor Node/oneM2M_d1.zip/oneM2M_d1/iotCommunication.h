/*
 *  iotCommunication.ino
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Implementation of Generic IoT Communication functions. Will use oneM2M functions.
 */

#ifndef iotCommunication_H
#define iotCommunication_H

# include "oneM2MTypes.h"

extern bool isIotConnected;

bool iotInit(String URL, int port, boolean secureConnection, boolean oauthEnabled, String path, String rn, String originator);
bool iotRegisterDevice(String aeID, String nodeID);
bool iotSendTemperature(float temperature);
bool iotSendHumidity(float humidity);
bool iotSendBattery(float batteryLevel, BatteryStatus status);
bool iotUpdateDeviceTime();
bool iotCheckNotification();
# endif
