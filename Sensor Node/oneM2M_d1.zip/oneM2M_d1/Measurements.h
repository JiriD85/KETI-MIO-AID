/*
 *  Measurements.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Implementation of various measurement functions.
 */

# include "oneM2MTypes.h"

//
//  DHTxx
//

extern float   humidity;
extern float   humidityLast;
extern float   temperature;
extern float   temperatureLast;

bool dhtInit();
bool dhtStatus();


//
//  Current
//

extern BatteryStatus batteryStatus;
extern float voltage;
extern float voltageDivider;
extern float voltageNominal;
extern float voltageFull;
extern float voltageEmpty;
extern float deadVoltage; 
extern float voltagePercentage;

bool batteryMeterInit();
bool batteryMeterStatus();


//
//  Button
//


extern bool buttonState;
extern bool buttonSwitch;

extern bool buttonInit();
extern bool buttonPoll();
extern bool buttonReset();
