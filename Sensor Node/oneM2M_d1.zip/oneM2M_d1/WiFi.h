/*
 *  WiFi.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Implementation of WiFi functions.
 */

#define WIFICONNECTRETRIES  10         // increase this in case the WiFi connection takes some time to establish
#define WIFICONNECTDELAY    500        // ms to wait during a connection attempt


extern bool    isWifiConnected;
extern String  ssid;
extern String  wifipw;

bool wifiConnect(String _ssid, String _wifipw);
