/*
 *  Display.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Implementation of display functions.
 */
# ifndef __DISPLAY__
# define __DISPLAY__

bool displayInit();
void displayPrint(int x, int y, String msg);
void displayPrintln(int x, int y, String msg);
void displayClear();

void displayIndicator(int pos, String indicator, bool enabled);
void displayTitle(String msg);
void displayBanner(String msg);

# endif
