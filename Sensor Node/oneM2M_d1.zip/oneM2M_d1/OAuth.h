/*
 *  OAuth.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Implementation of oAuth token retrieval.
 */

# ifndef __OAUTH__
# define __OAUTH__

class OAuthToken {

private:
  String        _host;
  int           _port;
  String        _path;
  String        _clientID;
  String        _clientSecret;

public:
  String        token;
  unsigned long expiration;


  OAuthToken(String host, String path, String clientID, String clientSecret);

  bool renew();
  bool isExpired();

};

String getAuthToken(String host, String path, String clientID, String clientSecret);


# endif
