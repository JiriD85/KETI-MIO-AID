/*
 *  Buzzer.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Definitions for Buzzer & Melodies
 */


# ifndef __BUZZER__
# define __BUZZER__


# define note_a  1136 //Note a
# define note_c  1915 //Note c
# define note_d  1700 //Note d
# define note_e  1519 //Note e
# define note_f  1432 //Note f
# define note_g  1275 //Note g

# define note_c3    7634
# define note_d3    6803
# define note_e3    6061
# define note_f3    5714
# define note_g3    5102
# define note_a3    4545
# define note_b3    4049
# define note_c4    3816    // 261 Hz 
# define note_d4    3401    // 294 Hz 
# define note_e4    3030    // 329 Hz 
# define note_f4    2865    // 349 Hz 
# define note_g4    2551    // 392 Hz 
# define note_a4    2272    // 440 Hz 
# define note_a4s   2146
# define note_b4    2028    // 493 Hz 
# define note_c5    1912    // 523 Hz
# define note_d5    1706
# define note_d5s   1608
# define note_e5    1517    // 659 Hz
# define note_f5    1433    // 698 Hz
# define note_g5    1276
# define note_a5    1136
# define note_a5s   1073
# define note_b5    1012
# define note_c6    955
 
# define note_pause -1 // Pause


extern int melodyImperialMarch[];
extern int beatsImperialMarch[];
extern int lengthImperialMarch;

extern int melodyStarWarsTheme[];
extern int beatsStarWarsTheme[];
extern int lengthStarWarsTheme;

extern void buzzerInit();
extern void playMelody(int notes[], int beat[], int numberOfNotes);
extern void playTone(int tone, int duration);

# endif
