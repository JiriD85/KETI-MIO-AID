/*
 *  Configuration.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Implementation of configuration functions.
 */

# ifndef __CONFIGURATION__
# define __CONFIGURATION__

// Some configurations
# define WIFIAPNAME          "WEMOSD1"  // name of the configuration WiFi network
# define CFGUPTIME           300000     // uptime for the config server (5 minutes)
//# define CFGUPTIME              5000     // uptime for the config server (5 sekunden)

# define WIFICONNECTRETRIES     10      // increase this in case the WiFi connection takes some time to establish
# define WIFICONNECTDELAY      500      // ms to wait during a connection attempt

# define CSESECURECONNECTION  "off"     // Default: http
# define MEASURINGINT         5000      // ms for the measuring intervall
# define BATTERYCHECKINT     30000      // ms for the battery check intervall
# define CSECHECKINT         60000      // ms between checks for CSE connectivity
# define WIFICHECKINT        10000      // ms between checks for WiFi connectivity

# define VOLTAGENOMINAL        3.7      // V nominal 
# define VOLTAGEFULL           3.5      // V of full battery
# define VOLTAGEEMPTY          3.0      // V of empty battery
# define BATTERYPERCENTAGELOW   10      // Percentage of low battery indicator

# define OAUTHENABLED         "off"     // Default: off




extern String config_ssid;
extern String config_wifipw;
extern String config_cseHost;
extern String config_csePort;
extern String config_cseSecureConnection;
extern String config_csePath;
extern String config_cseOriginator;
extern String config_cseName;
extern String cconfig_seAEID;
extern String config_measuringInterval;
extern String config_batteryCheckInterval;
extern String config_cseCheckInterval;
extern String config_wifiCheckInterval;
extern String config_voltageNominal;
extern String config_voltageFull;
extern String config_voltageEmpty;
extern String config_batteryPercentageLow;
extern String config_oauthEnabled;
extern String config_oauthHost;
extern String config_oauthPath;
extern String config_oauthURL;
extern String config_oauthClientID;
extern String config_oauthClientSecret;


extern bool configurationCheck();
extern bool configurationInit();
extern bool configurationFinish();
extern bool configurationIsActive();

void loadStoreConfig();
void saveStoreConfig(const String configuration[]);

# endif
