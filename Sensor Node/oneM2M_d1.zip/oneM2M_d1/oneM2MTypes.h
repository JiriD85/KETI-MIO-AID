/*
 *  oneM2MTypes.h
 *
 *  copyright (c) Andreas Kraft 2022
 *  Licensed under the BSD 3-Clause License. See the LICENSE file for further details.
 *
 *  Various oneM2M types and definitions.
 */


# ifndef oneM2MTypes_H
# define oneM2MTypes_H
 
 enum BatteryStatus {
  NORMAL = 1,
  CHARGING = 2,
  CHARGING_COMPLETE = 3,
  DAMAGED = 4,
  LOW_BATTERY = 5,
  NOT_INSTALLED = 6,
  UNKNOWN = 7  
};

# endif
